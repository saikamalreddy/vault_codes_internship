// Add any JavaScript functionality you need here
// For demonstration purposes, we'll just alert a message
function applyNowClicked() {
    alert('You have applied for this internship. Good luck!');
}

const applyButtons = document.querySelectorAll('.cta-button');

applyButtons.forEach(button => {
    button.addEventListener('click', applyNowClicked);
});